<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Try Again</name>
   <tag></tag>
   <elementGuidId>9385b7e3-b831-4ecb-aafe-ffe25aaab462</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>.//*[text()='Try Again !']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
