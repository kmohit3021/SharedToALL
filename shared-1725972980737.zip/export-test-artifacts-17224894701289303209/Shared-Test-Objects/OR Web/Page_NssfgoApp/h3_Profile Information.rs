<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Profile Information</name>
   <tag></tag>
   <elementGuidId>3cf37529-b592-476f-9c30-d5171b440180</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h3[(text() = 'Profile Information' or . = 'Profile Information')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h3.card-title.text-gray-200.fs-2x.text-uppercase.fw-bolder</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Profile Information&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>c277ae5e-0ce8-4fb4-9915-07add0e8e241</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>card-title text-gray-200 fs-2x text-uppercase fw-bolder</value>
      <webElementGuid>0e88be35-aded-4a0a-947f-277dd59584b1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Profile Information</value>
      <webElementGuid>d301e209-25c3-4f85-ac7d-7994c45072d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;statement_table&quot;)/div[@class=&quot;container _pdf-container&quot;]/div[@class=&quot;card card-dashed&quot;]/div[@class=&quot;card-header bg-blue&quot;]/h3[@class=&quot;card-title text-gray-200 fs-2x text-uppercase fw-bolder&quot;]</value>
      <webElementGuid>928d610a-2307-461d-bc9e-24633c795c69</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'Profile Information' or . = 'Profile Information')]</value>
      <webElementGuid>1c646327-9a5e-4e5c-942d-0c83634e8190</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Paid on Jun 30, 2011'])[1]/following::h3[1]</value>
      <webElementGuid>db106304-5236-4a0e-8bc6-23e726665fa6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contributions'])[169]/following::h3[1]</value>
      <webElementGuid>fa6ff90d-50fc-4201-9483-2c7e5ea26919</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NSSF Number'])[1]/preceding::h3[1]</value>
      <webElementGuid>81eb557b-e38f-4718-add8-24e9b759d9f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name'])[1]/preceding::h3[1]</value>
      <webElementGuid>fe78b34f-3577-433f-9ee2-cab2ad14f63b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Profile Information']/parent::*</value>
      <webElementGuid>fa6cdd28-ccd9-414a-a6a5-6eb6cc9ee402</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='statement_table']/div/div[2]/div/h3</value>
      <webElementGuid>5a0289e3-ba77-47c9-a6ff-251483389fe2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h3</value>
      <webElementGuid>2706f13c-e406-4a4c-9d70-f6160b0ed9fd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
