<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Hello, Emmanuel Sserumaga</name>
   <tag></tag>
   <elementGuidId>7646dc44-e21d-41cd-baf8-a6d21c60af65</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[(text() = ' Hello, Emmanuel Sserumaga' or . = ' Hello, Emmanuel Sserumaga')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.text-white.fw-bold.fs-7.me-3</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Hello, Emmanuel Sserumaga&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>0f54ca1e-d7e3-48b7-b31b-d6fa5088b9d1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-white fw-bold fs-7 me-3</value>
      <webElementGuid>dd2632e8-5145-4d61-92c2-8e9631259b00</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Hello, Emmanuel Sserumaga</value>
      <webElementGuid>c44409e9-07ac-4a1d-a821-b6d3d6a228bd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;kt_header&quot;)/div[@class=&quot;header-container container&quot;]/div[@class=&quot;d-flex align-items-center flex-wrap&quot;]/div[@class=&quot;d-flex align-items-center py-3 py-lg-0&quot;]/app-mini-profile[1]/div[@class=&quot;me-3&quot;]/div[@class=&quot;dropdown&quot;]/span[@class=&quot;text-white fw-bold fs-7 me-3&quot;]</value>
      <webElementGuid>9ea31f4e-98f9-4bfb-969d-d8e73dab2049</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = ' Hello, Emmanuel Sserumaga' or . = ' Hello, Emmanuel Sserumaga')]</value>
      <webElementGuid>fe86ac58-ad55-44ec-a43f-2f798e4021b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Member Dashboard'])[1]/following::span[1]</value>
      <webElementGuid>da1c7002-65bc-47e2-be80-6fbc25d97f72</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::span[1]</value>
      <webElementGuid>45a701e3-590d-4b44-89a7-94e80fd8a74e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Emmanuel Sserumaga'])[1]/preceding::span[1]</value>
      <webElementGuid>5586965f-2a24-47c6-af5c-7f74d5c62734</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My Profile'])[1]/preceding::span[1]</value>
      <webElementGuid>112a87c2-2be1-4e52-bacb-a105963e9813</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Hello, Emmanuel Sserumaga']/parent::*</value>
      <webElementGuid>bfa7d450-0340-4f1c-aeba-6129830128c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='kt_header']/div/div[2]/div/app-mini-profile/div/div/span</value>
      <webElementGuid>8eb0178f-b8c5-4da1-a2d1-2a258c8566f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//app-mini-profile/div/div/span</value>
      <webElementGuid>4f6bffbb-43a4-40ad-ad0c-fa0066c65953</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
