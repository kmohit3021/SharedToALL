<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Contributions</name>
   <tag></tag>
   <elementGuidId>419e29ab-8db2-484d-8666-1aaba59d3121</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[(text() = 'Contributions' or . = 'Contributions')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>td.text-gray-600 > span > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;Contributions National Social Security Fund 2,447,084 7 / 2024 Aug 15, 2024&quot;i] >> span >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>aff9640d-5865-4852-a352-655115a3b944</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Contributions</value>
      <webElementGuid>c90f7e84-ac94-4437-b190-e39c46b48295</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;statement_table&quot;)/div[@class=&quot;container _pdf-container&quot;]/div[@class=&quot;card shadow-sm mt-10 card-dashed&quot;]/div[@class=&quot;card-body&quot;]/div[@class=&quot;table-responsive&quot;]/div[@class=&quot;table-responsive&quot;]/div[@class=&quot;table-responsive&quot;]/table[@class=&quot;table table-bordered&quot;]/tbody[@class=&quot;fs-4&quot;]/tr[1]/td[@class=&quot;text-gray-600&quot;]/span[1]/span[1]</value>
      <webElementGuid>30dad0b6-8daf-4465-b22a-8aab85192611</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Contributions' or . = 'Contributions')]</value>
      <webElementGuid>10849dcb-7eeb-4008-87ac-c7fe4c5fc910</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Paid on'])[1]/following::span[2]</value>
      <webElementGuid>aacddd05-8c0a-4955-8682-575fe0566644</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Period'])[1]/following::span[2]</value>
      <webElementGuid>b48c5e0f-6124-4391-8568-a38a3bc5790a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='National Social Security Fund'])[87]/preceding::span[1]</value>
      <webElementGuid>19dbd888-76d1-416e-ae8e-50befecccca9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Aug 15, 2024'])[2]/preceding::span[1]</value>
      <webElementGuid>de57a52a-9374-43b3-a8c3-b8e14769b1c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='statement_table']/div/div[3]/div[2]/div/div/div/table/tbody/tr/td/span/span</value>
      <webElementGuid>091614ba-760c-4932-a12b-9a466907ac8a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td/span/span</value>
      <webElementGuid>3fcad2cb-ce46-4991-8e67-ca083a6b578a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
