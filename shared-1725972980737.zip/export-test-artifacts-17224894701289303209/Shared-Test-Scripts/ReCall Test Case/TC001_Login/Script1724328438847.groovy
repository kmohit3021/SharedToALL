import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

WebUI.openBrowser('')

WebUI.navigateToUrl('https://nssfgo.app/landing')

WebUI.click(findTestObject('Object Repository/OR Web/Page_NssfgoApp/a_Log into your account'))

WebUI.setText(findTestObject('Object Repository/OR Web/Page_NssfgoApp/input_Mobile Number or Email_form-control __9cb53f'), 
    'katsmakaato@gmail.com')

WebUI.click(findTestObject('Object Repository/OR Web/Page_NssfgoApp/span_Login'))

WebUI.delay(5)

boolean isVisibleOtpBox = WebUI.verifyElementVisible(findTestObject('OR Web/Page_NssfgoApp/Try Again'), FailureHandling.OPTIONAL)

if (isVisibleOtpBox) {
    WebUI.click(findTestObject('OR Web/Page_NssfgoApp/Try Again'))

    WebUI.click(findTestObject('Object Repository/OR Web/Page_NssfgoApp/span_Login'))
}

WebUI.delay(20)

def otp = CustomKeywords.'com.katalon.email.LoginOTP.getOTPGmail'()

WebUI.sendKeys(findTestObject('OR Web/Page_NssfgoApp/input_Enter the verification code here_form_196606'), otp)

WebUI.click(findTestObject('Object Repository/OR Web/Page_NssfgoApp/span_Login'))

WebUI.delay(10)