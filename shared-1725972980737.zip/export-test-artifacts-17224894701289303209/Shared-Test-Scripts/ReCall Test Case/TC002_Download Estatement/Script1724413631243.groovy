import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

WebUI.waitForElementPresent(findTestObject('Object Repository/OR Web/Page_NssfgoApp/img_Dasboard_h-20px'), 20)

WebUI.click(findTestObject('Object Repository/OR Web/Page_NssfgoApp/span_Hello, Emmanuel Sserumaga'))

WebUI.verifyElementText(findTestObject('Object Repository/OR Web/Page_NssfgoApp/span_Hello, Emmanuel Sserumaga'), 'Hello, Emmanuel Sserumaga')

WebUI.click(findTestObject('Object Repository/OR Web/Page_NssfgoApp/span_Dasboard_menu-icon'))

WebUI.waitForElementVisible(findTestObject('Object Repository/OR Web/Page_NssfgoApp/span_E-Statement'), 20)

WebUI.click(findTestObject('Object Repository/OR Web/Page_NssfgoApp/button_Download'))

WebUI.waitForElementVisible(findTestObject('Object Repository/OR Web/Page_NssfgoApp/h3_Profile Information'), 20)

WebUI.verifyElementText(findTestObject('Object Repository/OR Web/Page_NssfgoApp/h3_Profile Information'), 'PROFILE INFORMATION')

List<WebElement> countContributions = WebUI.findWebElements(findTestObject('Object Repository/OR Web/Page_NssfgoApp/span_Contributions'), 
    0)

if (countContributions.size() > 0) {
    WebUI.comment('Total not of Contributions on the download page is: ' + countContributions.size())
}

//WebUI.click(findTestObject('Object Repository/OR Web/Page_NssfgoApp/button_Download_1'))
//WebUI.closeBrowser()

