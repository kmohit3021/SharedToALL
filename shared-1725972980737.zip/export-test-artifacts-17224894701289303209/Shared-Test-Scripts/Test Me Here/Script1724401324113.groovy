import java.util.regex.Matcher as Matcher
import java.util.regex.Pattern as Pattern
import javax.mail.BodyPart as BodyPart
import javax.mail.Folder as Folder
import javax.mail.Message as Message
import javax.mail.Session as Session
import javax.mail.Store as Store
import javax.mail.internet.MimeMultipart as MimeMultipart
import org.jsoup.Jsoup as Jsoup
import internal.GlobalVariable as GlobalVariable

String mailFolderName = 'INBOX'

String emailSubjectContent = 'Login Confirmation Code'

String emailContent = 'Hi there kindly use this as your one time confirmation code  <b>'

int lengthOfOTP = 5

String hostName = 'imap.gmail.com' //change it according to your mail

String username = 'katsmakaato@gmail.com' //username

String password = 'qtdr bqia cfeg lihd'

String searchText = null

Properties sysProps = new Properties()

sysProps.put('mail.store.protocol', 'imaps')

sysProps.put('mail.imaps.socketFactory.class', 'javax.net.ssl.SSLSocketFactory')

sysProps.put('mail.imaps.socketFactory.fallback', 'false')

sysProps.put('mail.imaps.port', '993')

sysProps.put('mail.imaps.socketFactory.port', '993')

sysProps.put('mail.imaps.ssl.protocols', 'TLSv1.2')

Session session = Session.getDefaultInstance(sysProps, null)

//session.setDebug(true)
Store store = session.getStore('imaps')

store.connect(hostName, username, password)

Folder emailFolder = store.getFolder(mailFolderName)

emailFolder.open(Folder.READ_ONLY)

// retrieve the messages from the folder in an array and print it
Message[] messages = emailFolder.getMessages()

System.out.println('messages.length---' + messages.length)

int msglen = messages.length - 1

for (int i = msglen; i >= 0; i--) {
    Message message = messages[i]

    System.out.println('---------------------------------')

    //System.out.println('Email Number ' + (i + 1))
    //System.out.println('Subject: ' + message.getSubject())
    //System.out.println('From: ' + (message.getFrom()[0]))
    Object content = message.getContent()

    if (message.getSubject().startsWith(emailSubjectContent)) {
        if (content instanceof String) {
            System.out.println('Email Number ' + (i + 1))

            System.out.println('Subject: ' + message.getSubject())

            System.out.println('From: ' + (message.getFrom()[0]))

            System.out.println('Text: ' + content)

            String intOTP = extractOTP(content)

            System.out.println('OTP from Gmail is: ' + intOTP)

            break
        } else if (content instanceof MimeMultipart) {
            System.out.println('Email Number ' + (i + 1))

            System.out.println('Subject: ' + message.getSubject())

            System.out.println('From: ' + (message.getFrom()[0]))

            System.out.println('Text: ' + getMutipartMessage(content))

            String intOTP = extractOTP(getMutipartMessage(content))

            System.out.println('OTP from Gmail is: ' + intOTP)

            break
        }
    }
}

//close the store and folder objects
emailFolder.close(false)

store.close() // Group 1 contains the digits within <b> and </b>
// Return null if no OTP found

def getMutipartMessage(MimeMultipart mimeMultipart) {
    String result = ''

    int count = mimeMultipart.getCount()

    for (def j : (0..count - 1)) {
        BodyPart bodyPart = mimeMultipart.getBodyPart(j)

        if (bodyPart.isMimeType('text/plain')) {
            result = ((result + '\n') + bodyPart.getContent())

            break
        } else if (bodyPart.isMimeType('text/html')) {
            String html = ((bodyPart.getContent()) as String)

            result = ((result + '\n') + Jsoup.parse(html).text())
        }
    }
    
    return result
}

String extractOTP(String message) {
    String regex = '<b>(\\d+)</b>'

    Pattern pattern = Pattern.compile(regex)

    Matcher matcher = pattern.matcher(message)

    if (matcher.find()) {
        return matcher.group(1)
    } else {
    }
}