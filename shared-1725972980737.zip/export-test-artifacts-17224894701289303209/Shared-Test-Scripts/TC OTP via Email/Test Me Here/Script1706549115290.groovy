
import microsoft.exchange.webservices.data.core.ExchangeService;
import microsoft.exchange.webservices.data.core.PropertySet
import microsoft.exchange.webservices.data.core.enumeration.property.BasePropertySet;
import microsoft.exchange.webservices.data.core.enumeration.property.WellKnownFolderName;
import microsoft.exchange.webservices.data.core.service.item.EmailMessage;
import microsoft.exchange.webservices.data.credential.WebCredentials
import microsoft.exchange.webservices.data.search.FindItemsResults;
import microsoft.exchange.webservices.data.search.ItemView;

			try {
				ExchangeService service = new ExchangeService();
				service.setUrl(new java.net.URI("https://outlook.office365.com/EWS/Exchange.asmx"));
				service.setCredentials(new WebCredentials('mohit.kumar@katalon.com', 'Katalon@2'));
	
				// Define the folder to read emails from (e.g., Inbox)
				WellKnownFolderName folderName = WellKnownFolderName.Inbox;
	
				// Create a view with a page size to limit the number of items returned
				ItemView view = new ItemView(10);
				
				// Specify the properties to be retrieved for each email
				PropertySet propertySet = new PropertySet(BasePropertySet.FirstClassProperties);
				view.setPropertySet(propertySet);
	
				// Find emails in the specified folder
				FindItemsResults<EmailMessage> findResults = service.findItems(folderName, view);
	
				// Iterate through the results and process each email
				for (EmailMessage email : findResults.getItems()) {
					System.out.println("Subject: " + email.getSubject());
					System.out.println("From: " + email.getFrom().getName());
					System.out.println("Body: " + email.getBody());
					// Additional processing can be done here
				}
			} catch (Exception e) {
				e.printStackTrace();
			}