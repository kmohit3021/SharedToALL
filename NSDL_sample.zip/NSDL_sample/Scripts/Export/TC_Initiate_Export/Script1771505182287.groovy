import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import crypto.CryptoUtil
import javax.crypto.SecretKey
import internal.GlobalVariable
import com.google.gson.Gson
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Random

// ===============================
// STEP 1: GET TOKEN FIRST
// ===============================

// Call your existing token test case or store token globally
def token = GlobalVariable.accessToken  // make sure token saved earlier

// ===============================
// STEP 2: Generate Dynamic Headers
// ===============================

def timestamp = new SimpleDateFormat("ddMMyyyyHHmmss").format(new Date())
def random4 = new Random().nextInt(9000) + 1000
def requestRefNo = GlobalVariable.requestorId + timestamp + random4
def requestTime = timestamp

// ===============================
// STEP 3: Create Plain Payload
// ===============================

def payload = [
        dpId        : GlobalVariable.clientId,
        businessDate: "2025-08-07",
        exportName  : "SOT",
        inputParams : [
                exportType     : "1",
                downloadOption : "F",
                statementDate  : "2025-08-07",
                fromDate       : "2025-08-07",
                toDate         : "2025-08-07",
                clientIDFrom   : "80000001",
                clientIDTo     : "80000002",
                POADDPIFrom    : "",
                POADDPITo      : "",
                ISINListing    : "1",
                ISINType       : "1",
                fromIssuanceDate: "2025-08-07",
                toIssuanceDate : "2025-08-07",
                fromDISno      : "0010000002",
                toDISno        : "0010000022",
                ISIN           : "INE602A01023",
                flag           : "1"
        ]
]

def gson = new Gson()
def payloadJson = gson.toJson(payload)

// ===============================
// STEP 4: Encryption
// ===============================

SecretKey aesKey = CryptoUtil.generateAESKey()

String encryptedPayload = CryptoUtil.encryptAES(payloadJson, aesKey)

String encryptedKey = CryptoUtil.encryptRSA(
        aesKey.getEncoded(),
        GlobalVariable.nsdlPublicKey
)

// ===============================
// STEP 5: Send Request
// ===============================

def response = WS.sendRequest(findTestObject(
        'Object Repository/Requests/9.2 Request Export API/ExportInitiateAPI',
        [
                ('txnReqRef'): encryptedKey,
                ('reqData')  : encryptedPayload,
                ('requestRefNo'): requestRefNo,
                ('requestTime'): requestTime,
                ('token')    : token
        ]
))

WS.verifyResponseStatusCode(response, 200)

// ===============================
// STEP 6: Decrypt Response
// ===============================

def json = new JsonSlurper().parseText(response.getResponseText())

String encryptedRespKey = json.txnRespRef
String encryptedRespData = json.respData

byte[] decryptedAESKeyBytes = CryptoUtil.decryptRSA(
        encryptedRespKey,
        GlobalVariable.dpPrivateKey
)

SecretKey responseAESKey = new javax.crypto.spec.SecretKeySpec(decryptedAESKeyBytes, "AES")

String decryptedResponse = CryptoUtil.decryptAES(
        encryptedRespData,
        responseAESKey
)

println("Decrypted Export Response: " + decryptedResponse)

// ===============================
// STEP 7: Validate Response
// ===============================

def exportResponse = new JsonSlurper().parseText(decryptedResponse)

assert exportResponse.status != null

if(exportResponse.status == "1") {
    println("Export Requested Successfully")
}
else if(exportResponse.status == "2") {
    println("No Records Found")
}
else if(exportResponse.status == "3") {
    println("Export Completed")
}
else if(exportResponse.status == "4") {
    println("Error Occurred")
}
