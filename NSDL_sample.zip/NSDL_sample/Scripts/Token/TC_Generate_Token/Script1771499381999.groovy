import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.google.gson.Gson
import crypto.CryptoUtil
import javax.crypto.SecretKey
import internal.GlobalVariable
import groovy.json.JsonSlurper

// Step 1: Create Plain Payload
def payload = [
        grant_type   : "client_credentials",
        client_id    : GlobalVariable.clientId,
        client_secret: GlobalVariable.clientSecret,
        scope        : GlobalVariable.scope
]

def gson = new Gson()
def payloadJson = gson.toJson(payload)

// Step 2: Generate AES Key
SecretKey aesKey = CryptoUtil.generateAESKey()

// Step 3: Encrypt Payload
String encryptedPayload = CryptoUtil.encryptAES(payloadJson, aesKey)

// Step 4: Encrypt AES Key with NSDL Public Key
String encryptedKey = CryptoUtil.encryptRSA(aesKey.getEncoded(), GlobalVariable.nsdlPublicKey)

// Step 5: Send Request
def response = WS.sendRequest(findTestObject('Object Repository/Requests/9.1 Token API/9.1.1 Token Request', [
        ('txnReqRef') : encryptedKey,
        ('reqData')   : encryptedPayload
]))

WS.verifyResponseStatusCode(response, 200)

// Step 6: Parse Encrypted Response
def json = new JsonSlurper().parseText(response.getResponseText())

String encryptedRespKey = json.txnRespRef
String encryptedRespData = json.respData

// Step 7: Decrypt Random Key using DP Private Key
byte[] decryptedAESKeyBytes = CryptoUtil.decryptRSA(encryptedRespKey, GlobalVariable.dpPrivateKey)
SecretKey responseAESKey = new javax.crypto.spec.SecretKeySpec(decryptedAESKeyBytes, "AES")

// Step 8: Decrypt Response Payload
String decryptedResponse = CryptoUtil.decryptAES(encryptedRespData, responseAESKey)

println("Decrypted Response: " + decryptedResponse)

// Step 9: Validate JWT
def tokenJson = new JsonSlurper().parseText(decryptedResponse)


GlobalVariable.accessToken = tokenJson.access_token
assert tokenJson.access_token != null
assert tokenJson.token_type.equalsIgnoreCase("bearer")
assert tokenJson.expires_in == 3600

