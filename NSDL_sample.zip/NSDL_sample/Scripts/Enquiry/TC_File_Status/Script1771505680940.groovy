import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import crypto.CryptoUtil
import javax.crypto.SecretKey
import internal.GlobalVariable
import com.google.gson.Gson
import groovy.json.JsonSlurper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Random

// ===============================
// STEP 1: GET TOKEN
// ===============================

def token = GlobalVariable.accessToken

// ===============================
// STEP 2: Generate Headers
// ===============================

def timestamp = new SimpleDateFormat("ddMMyyyyHHmmss").format(new Date())
def random4 = new Random().nextInt(9000) + 1000
def requestRefNo = GlobalVariable.requestorId + timestamp + random4
def requestTime = timestamp

// ===============================
// STEP 3: Create Payload
// ===============================

def payload = [
        requestId  : "10000000000001",
        requestType: "fileStat"
]

def gson = new Gson()
def payloadJson = gson.toJson(payload)

// ===============================
// STEP 4: Encrypt
// ===============================

SecretKey aesKey = CryptoUtil.generateAESKey()

String encryptedPayload = CryptoUtil.encryptAES(payloadJson, aesKey)

String encryptedKey = CryptoUtil.encryptRSA(
        aesKey.getEncoded(),
        GlobalVariable.nsdlPublicKey
)

// ===============================
// STEP 5: Send Request
// ===============================

def response = WS.sendRequest(findTestObject(
        'Object Repository/Requests/9.4 Enquiry API/EnquiryAPI',
        [
                ('txnReqRef'): encryptedKey,
                ('reqData')  : encryptedPayload,
                ('requestRefNo'): requestRefNo,
                ('requestTime'): requestTime,
                ('token')    : token
        ]
))

WS.verifyResponseStatusCode(response, 200)

// ===============================
// STEP 6: Decrypt Response
// ===============================

def json = new JsonSlurper().parseText(response.getResponseText())

String encryptedRespKey = json.data.txnReqRef
String encryptedRespData = json.data.reqData

byte[] decryptedAESKeyBytes = CryptoUtil.decryptRSA(
        encryptedRespKey,
        GlobalVariable.dpPrivateKey
)

SecretKey responseAESKey = new javax.crypto.spec.SecretKeySpec(decryptedAESKeyBytes, "AES")

String decryptedResponse = CryptoUtil.decryptAES(
        encryptedRespData,
        responseAESKey
)

println("Decrypted Enquiry Response: " + decryptedResponse)

// ===============================
// STEP 7: Validate Status
// ===============================

def enquiryResponse = new JsonSlurper().parseText(decryptedResponse)

println("Request Type: " + enquiryResponse.requestType)
println("Status: " + enquiryResponse.status)

switch(enquiryResponse.status) {
    case "1":
        println("Requested")
        break
    case "2":
        println("No Records")
        break
    case "3":
        println("Successfully Exported")
        break
    case "4":
        println("Error")
        break
}
