package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object baseUrl
     
    /**
     * <p></p>
     */
    public static Object requestorId
     
    /**
     * <p></p>
     */
    public static Object clientId
     
    /**
     * <p></p>
     */
    public static Object clientSecret
     
    /**
     * <p></p>
     */
    public static Object scope
     
    /**
     * <p></p>
     */
    public static Object nsdlPublicKey
     
    /**
     * <p></p>
     */
    public static Object dpPrivateKey
     
    /**
     * <p></p>
     */
    public static Object accessToken
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables('default')
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
    
            baseUrl = selectedVariables['baseUrl']
            requestorId = selectedVariables['requestorId']
            clientId = selectedVariables['clientId']
            clientSecret = selectedVariables['clientSecret']
            scope = selectedVariables['scope']
            nsdlPublicKey = selectedVariables['nsdlPublicKey']
            dpPrivateKey = selectedVariables['dpPrivateKey']
            accessToken = selectedVariables['accessToken']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
