package crypto

import javax.crypto.*
import javax.crypto.spec.SecretKeySpec
import java.security.*
import java.security.spec.*
import java.util.Base64
import com.google.gson.Gson

class CryptoUtil {

    static SecretKey generateAESKey() {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES")
        keyGen.init(256)
        return keyGen.generateKey()
    }

    static String encryptAES(String data, SecretKey key) {
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        byte[] encrypted = cipher.doFinal(data.getBytes())
        return Base64.encoder.encodeToString(encrypted)
    }

    static String decryptAES(String encryptedData, SecretKey key) {
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding")
        cipher.init(Cipher.DECRYPT_MODE, key)
        byte[] decoded = Base64.decoder.decode(encryptedData)
        return new String(cipher.doFinal(decoded))
    }

    static String encryptRSA(byte[] data, String publicKeyStr) {
        publicKeyStr = publicKeyStr.replaceAll("-----.*?-----", "").replaceAll("\\s", "")
        byte[] keyBytes = Base64.decoder.decode(publicKeyStr)
        X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes)
        KeyFactory factory = KeyFactory.getInstance("RSA")
        PublicKey publicKey = factory.generatePublic(spec)

        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding")
        cipher.init(Cipher.ENCRYPT_MODE, publicKey)
        byte[] encrypted = cipher.doFinal(data)
        return Base64.encoder.encodeToString(encrypted)
    }

    static byte[] decryptRSA(String encryptedData, String privateKeyStr) {
        privateKeyStr = privateKeyStr.replaceAll("-----.*?-----", "").replaceAll("\\s", "")
        byte[] keyBytes = Base64.decoder.decode(privateKeyStr)
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes)
        KeyFactory factory = KeyFactory.getInstance("RSA")
        PrivateKey privateKey = factory.generatePrivate(spec)

        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding")
        cipher.init(Cipher.DECRYPT_MODE, privateKey)
        return cipher.doFinal(Base64.decoder.decode(encryptedData))
    }
}
