<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>EditButton</name>
   <tag></tag>
   <elementGuidId>c00477a3-b8cb-44ac-b758-99b689e6ad8d</elementGuidId>
   <imagePath>Screenshots/Targets/Page_TAWRID - Working Capital Finance/ProfileSetupPage_EditButton.png</imagePath>
   <selectorCollection>
      <entry>
         <key>IMAGE</key>
         <value>Screenshots/Targets/Page_TAWRID - Working Capital Finance/ProfileSetupPage_EditButton.png</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@uib-tooltip = 'Edit']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>DIV</value>
      <webElementGuid>20924c06-f68a-4243-be3c-afe4e0382709</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>xpath1716130056231</value>
      <webElementGuid>6d0c6f31-12db-4865-b589-b6377a0d6569</webElementGuid>
   </webElementProperties>
</WebElementEntity>
