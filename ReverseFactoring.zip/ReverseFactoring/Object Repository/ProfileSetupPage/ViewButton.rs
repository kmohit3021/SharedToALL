<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ViewButton</name>
   <tag></tag>
   <elementGuidId>273df69e-efe8-48f0-952d-005987622332</elementGuidId>
   <imagePath>Screenshots/Targets/Page_TAWRID - Working Capital Finance/ProfileSetupPage_ViewButton.png</imagePath>
   <selectorCollection>
      <entry>
         <key>IMAGE</key>
         <value>Screenshots/Targets/Page_TAWRID - Working Capital Finance/ProfileSetupPage_ViewButton.png</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@uib-tooltip = 'View']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>DIV</value>
      <webElementGuid>e4bbf938-efd8-4aab-9484-87f1b46b5906</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>xpath1716130083441</value>
      <webElementGuid>908bd170-3722-45cc-8b86-5921b22db20f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
