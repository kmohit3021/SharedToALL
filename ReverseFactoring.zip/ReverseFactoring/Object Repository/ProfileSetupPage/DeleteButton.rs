<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DeleteButton</name>
   <tag></tag>
   <elementGuidId>48446358-de45-48f1-915d-572738651dca</elementGuidId>
   <imagePath>Screenshots/Targets/Page_TAWRID - Working Capital Finance/ProfileSetupPage_DeleteButton.png</imagePath>
   <selectorCollection>
      <entry>
         <key>IMAGE</key>
         <value>Screenshots/Targets/Page_TAWRID - Working Capital Finance/ProfileSetupPage_DeleteButton.png</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@uib-tooltip = 'Delete'][1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>DIV</value>
      <webElementGuid>ad729c5c-6cac-4a64-9993-f8071284e8c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>xpath1716130002160</value>
      <webElementGuid>f84da874-ad93-49ec-8778-e7a2577d6047</webElementGuid>
   </webElementProperties>
</WebElementEntity>
