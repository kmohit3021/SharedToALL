<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>IndustryOption</name>
   <tag></tag>
   <elementGuidId>9d67e730-781e-4420-9dbe-3efdcc4d7a2e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>.//*[text()='11 - Agriculture']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
