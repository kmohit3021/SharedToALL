<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SelectAllCheck</name>
   <tag></tag>
   <elementGuidId>ffec5838-5656-4660-a902-6466d1e68a6d</elementGuidId>
   <imagePath>Screenshots/Targets/Page_TAWRID - Working Capital Finance/CreateCompanyPage_SelectAllCheck.png</imagePath>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Right'])[1]/following::label[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = ' ' or . = ' ')]</value>
      </entry>
      <entry>
         <key>IMAGE</key>
         <value>Screenshots/Targets/Page_TAWRID - Working Capital Finance/CreateCompanyPage_SelectAllCheck.png</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.ui-grid-header-cell.ui-grid-clearfix.fs-scope.fs-isolate-scope.ui-grid-coluiGrid-007D.hover > div.fs-scope > div.ui-grid-cell-contents > div.selectionSelectAllButtons.fs-scope.fs-not-empty.fs-valid > label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=checkbox</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>c4c5c533-252f-4203-9a5f-ef5f109d8cab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>selectAll1716120836686</value>
      <webElementGuid>00d0cd36-ac28-4080-8b85-d7555c302d72</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> </value>
      <webElementGuid>161414cc-d521-4e01-bc28-0dca229f46db</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;fs-scope&quot;]/body[@class=&quot;app fs-scope v-scroll&quot;]/div[@class=&quot;app-view fs-scope&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;app-content&quot;]/div[@class=&quot;content-body&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;bpt-form fs-scope&quot;]/form[@class=&quot;fs-pristine fs-valid-patterncheck fs-valid-emailcheck fs-valid-maxlength fs-invalid fs-invalid-required&quot;]/div[@class=&quot;panel fs-tabset&quot;]/div[@class=&quot;panel-body fs-tabset-head&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;tab-set&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;bpt-form fs-scope&quot;]/div[@class=&quot;panel-body fs-tabset-head&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;tab-set&quot;]/div[@class=&quot;fs-isolate-scope&quot;]/div[@class=&quot;tab-content&quot;]/div[@class=&quot;tab-pane fs-scope active&quot;]/fs-form[@class=&quot;fs-pristine fs-valid fs-scope&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;editPage fs-scope&quot;]/div[@class=&quot;fsLayout container-fluid&quot;]/div[@class=&quot;row panel-group&quot;]/div[@class=&quot;fsGroup&quot;]/div[@class=&quot;panel panel-default table-body col-md-12 disable-top-radius&quot;]/div[@class=&quot;panel-body&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;fsGridTable form-group&quot;]/fs-table[@class=&quot;fs-isolate-scope multiple-table&quot;]/div[@class=&quot;fsTable ui-grid fs-isolate-scope grid1716120836686&quot;]/div[@class=&quot;ui-grid-contents-wrapper&quot;]/div[@class=&quot;oprationContainer ui-grid-pinned-container fs-scope fs-isolate-scope ui-grid-pinned-container-left&quot;]/div[@id=&quot;1716120836686-grid-container&quot;]/div[@class=&quot;ui-grid-header fs-scope&quot;]/div[@class=&quot;ui-grid-top-panel&quot;]/div[@class=&quot;ui-grid-header-viewport&quot;]/div[@class=&quot;ui-grid-header-canvas&quot;]/div[@class=&quot;ui-grid-header-cell-wrapper&quot;]/div[@class=&quot;ui-grid-header-cell-row&quot;]/div[@class=&quot;ui-grid-header-cell ui-grid-clearfix fs-scope fs-isolate-scope ui-grid-coluiGrid-007D hover&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;ui-grid-cell-contents&quot;]/div[@class=&quot;selectionSelectAllButtons fs-scope fs-not-empty fs-valid&quot;]/label[1]</value>
      <webElementGuid>03430142-54a9-45f5-aea1-9c58c88d40fa</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='1716120836686-grid-container']/div/div/div/div/div/div/div/div/div/div/label</value>
      <webElementGuid>315b7cd0-a283-4650-83e7-9098f262eb56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Preview'])[1]/following::label[1]</value>
      <webElementGuid>08e87c6d-a04f-4f74-a220-418c6b0b2b1f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Right'])[1]/following::label[1]</value>
      <webElementGuid>1d66b1cb-033b-469b-9e3f-af1b570ebbed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Company Type'])[3]/preceding::label[52]</value>
      <webElementGuid>50298682-cf0b-41a9-98af-715255bbc1ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Category'])[1]/preceding::label[52]</value>
      <webElementGuid>5a2cc6c3-359b-4646-899d-8232364b6aec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div/div/div/fs-table/div/div[2]/div/div/div/div/div/div/div/div/div/div/div/div/label</value>
      <webElementGuid>8cf62787-9ce3-413b-9573-41896f97146e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = ' ' or . = ' ')]</value>
      <webElementGuid>82e6c12d-5d73-4519-9978-2c70696f4857</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
