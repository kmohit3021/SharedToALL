<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CreateCompanyLabel</name>
   <tag></tag>
   <elementGuidId>a85371e8-d7a6-4e31-9c31-130645fe01eb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>.//*[text()='Create Company']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
