<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>KYCProcessCompletedLabel</name>
   <tag></tag>
   <elementGuidId>606efae6-74e9-40b1-8158-44b369f054ab</elementGuidId>
   <imagePath>Screenshots/Targets/Page_TAWRID - Working Capital Finance/KYCProcessCompletedLabel.png</imagePath>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#1716294780469-0-uiGrid-00C4-cell > div.ui-grid-cell-contents.fs-scope.text-left > span.fs-binding</value>
      </entry>
      <entry>
         <key>IMAGE</key>
         <value>Screenshots/Targets/Page_TAWRID - Working Capital Finance/KYCProcessCompletedLabel.png</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@role='rowgroup'][2]/div/div/div[1]/div[1]/div[5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=gridcell[name=&quot;No&quot;i] >> span</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>4d3c9ab9-83e5-4b88-b411-31d5caff74a7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fs-binding</value>
      <webElementGuid>ac6f17ae-1fae-424b-bf88-f46a4d96985f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>No </value>
      <webElementGuid>de082dcf-dfbf-4fd9-ba70-a46e3dd230d6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;1716294780469-0-uiGrid-00C4-cell&quot;)/div[@class=&quot;ui-grid-cell-contents fs-scope text-left&quot;]/span[@class=&quot;fs-binding&quot;]</value>
      <webElementGuid>5f04106d-3913-4297-9204-e05d9f1becb2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='1716294780469-0-uiGrid-00C4-cell']/div/span</value>
      <webElementGuid>75471127-1fed-4069-93e5-1d2cb6594f11</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Action'])[1]/preceding::span[2]</value>
      <webElementGuid>592d3fa8-0665-487e-81a7-332f54042857</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/span</value>
      <webElementGuid>abc3ff1a-32b2-40bf-9926-3fa6aacf440d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'No ' or . = 'No ')]</value>
      <webElementGuid>13bc7652-ec4c-40cb-aab4-200162af00bd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
