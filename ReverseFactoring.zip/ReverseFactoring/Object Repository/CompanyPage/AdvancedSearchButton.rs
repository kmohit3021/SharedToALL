<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AdvancedSearchButton</name>
   <tag></tag>
   <elementGuidId>eb94dd93-f70e-4fe9-ab1d-63df95d2a457</elementGuidId>
   <imagePath>Screenshots/Targets/Page_TAWRID - Working Capital Finance/CompanyPage_AdvancedSearchButton.png</imagePath>
   <selectorCollection>
      <entry>
         <key>IMAGE</key>
         <value>Screenshots/Targets/Page_TAWRID - Working Capital Finance/CompanyPage_AdvancedSearchButton.png</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.advanced.col-sm-12.text-right.col-md-12.col-sm-12.col-xs-12 > fs-button.fs-scope.fs-isolate-scope > div.form-group.fs-scope > div.col-md-0 > button.btn.btn-primary.button > span.fs-binding</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Yes'])[1]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Advanced Search&quot;s]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>890be806-25e1-43f9-a582-537b2b3e08d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fs-binding</value>
      <webElementGuid>e313534d-16fa-431e-9b07-f8bb0c7355ae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Advanced Search</value>
      <webElementGuid>099cf157-28dd-4976-b287-6121a5b6caca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;fs-scope&quot;]/body[@class=&quot;app fs-scope v-scroll&quot;]/div[@class=&quot;app-view fs-scope&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;app-content&quot;]/div[@class=&quot;content-body&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;bpt-form fs-scope&quot;]/form[@class=&quot;fs-pristine fs-valid-patterncheck fs-valid fs-valid-maxlength fs-valid-min fs-valid-max fs-valid-required&quot;]/div[1]/fs-layout[@class=&quot;fs-isolate-scope&quot;]/div[@class=&quot;fsLayout container-fluid&quot;]/div[@class=&quot;row panel-group&quot;]/fs-group[@class=&quot;fs-scope fs-isolate-scope fsGroup&quot;]/div[@class=&quot;panel panel-default fs-scope search no-margin-bottom col-md-12 col-xs-12&quot;]/div[@class=&quot;panel-body in collapse&quot;]/div[@class=&quot;row fs-scope&quot;]/fs-grid[@class=&quot;fs-scope fs-isolate-scope fsGrid fsButton&quot;]/div[@class=&quot;advanced col-sm-12 text-right col-md-12 col-sm-12 col-xs-12&quot;]/fs-button[@class=&quot;fs-scope fs-isolate-scope&quot;]/div[@class=&quot;form-group fs-scope&quot;]/div[@class=&quot;col-md-0&quot;]/button[@class=&quot;btn btn-primary button&quot;]/span[@class=&quot;fs-binding&quot;]</value>
      <webElementGuid>7027df7b-0f44-40b0-8e04-37bf4313bc18</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Yes'])[1]/following::span[2]</value>
      <webElementGuid>495f86bd-6a8b-4755-bdea-134b2c02114e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='No'])[1]/following::span[3]</value>
      <webElementGuid>b4bae1b1-bed3-4bfe-9fad-f525c8a3288c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Company Code'])[1]/preceding::span[1]</value>
      <webElementGuid>164ebecf-14ab-445f-b714-7a09eec7dad3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Company Name'])[2]/preceding::span[3]</value>
      <webElementGuid>a6ec05b4-f672-41e0-a250-916750479970</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//fs-grid[5]/div/fs-button/div/div/button/span[2]</value>
      <webElementGuid>373171af-1434-478c-9d36-adec28162fba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Advanced Search' or . = 'Advanced Search')]</value>
      <webElementGuid>2fa67399-8efb-44fc-97fb-70b840ab0867</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
