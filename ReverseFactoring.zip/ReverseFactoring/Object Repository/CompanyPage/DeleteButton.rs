<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>DeleteButton</name>
   <tag></tag>
   <elementGuidId>3dac048a-372e-4327-97d9-f686ce6466a9</elementGuidId>
   <imagePath>Screenshots/Targets/Page_TAWRID - Working Capital Finance/CompanyPage_DeleteButton.png</imagePath>
   <selectorCollection>
      <entry>
         <key>IMAGE</key>
         <value>Screenshots/Targets/Page_TAWRID - Working Capital Finance/CompanyPage_DeleteButton.png</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@uib-tooltip = 'Delete'][1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>DIV</value>
      <webElementGuid>e89dd924-5032-42f0-8901-f25c682b4aed</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>xpath1716119348590</value>
      <webElementGuid>18fb03e0-cdf2-44b1-98f0-86a51a4d794f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
