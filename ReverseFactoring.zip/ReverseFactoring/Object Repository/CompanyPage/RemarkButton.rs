<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>RemarkButton</name>
   <tag></tag>
   <elementGuidId>21804f12-feee-4977-980f-54df9df6784a</elementGuidId>
   <imagePath>Screenshots/Targets/Page_TAWRID - Working Capital Finance/CompanyPage_RemarkButton.png</imagePath>
   <selectorCollection>
      <entry>
         <key>IMAGE</key>
         <value>Screenshots/Targets/Page_TAWRID - Working Capital Finance/CompanyPage_RemarkButton.png</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@uib-tooltip = 'Remark']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>DIV</value>
      <webElementGuid>eeb568b5-1605-4fd4-9b61-fb7105b84f9b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>xpath1716119471273</value>
      <webElementGuid>a0c11649-9dc6-4170-b60d-354a52f53095</webElementGuid>
   </webElementProperties>
</WebElementEntity>
