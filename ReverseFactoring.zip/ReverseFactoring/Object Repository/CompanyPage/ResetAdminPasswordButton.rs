<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ResetAdminPasswordButton</name>
   <tag></tag>
   <elementGuidId>f74c884d-3490-4a7f-a7c0-fab5f0305980</elementGuidId>
   <imagePath>Screenshots/Targets/Page_TAWRID - Working Capital Finance/CompanyPage_ResetAdminPasswordButton.png</imagePath>
   <selectorCollection>
      <entry>
         <key>IMAGE</key>
         <value>Screenshots/Targets/Page_TAWRID - Working Capital Finance/CompanyPage_ResetAdminPasswordButton.png</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@uib-tooltip = 'Reset Admins Password']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>DIV</value>
      <webElementGuid>c6503afd-c009-4db9-be76-ee883091b5f6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>xpath1716119401666</value>
      <webElementGuid>2526cc3d-3d68-48ea-836e-96f2dd8c7c12</webElementGuid>
   </webElementProperties>
</WebElementEntity>
