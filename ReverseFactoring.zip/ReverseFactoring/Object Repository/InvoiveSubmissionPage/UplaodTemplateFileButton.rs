<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>UplaodTemplateFileButton</name>
   <tag></tag>
   <elementGuidId>e6950cea-fb19-4bd7-b4be-d43f8a20255b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html[@class=&quot;fs-scope&quot;]/body[@class=&quot;app fs-scope v-scroll&quot;]/div[@class=&quot;app-view fs-scope&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;app-content&quot;]/div[@class=&quot;content-body&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;cpt-form editPage fs-scope&quot;]/fs-layout[@class=&quot;fs-isolate-scope&quot;]/div[@class=&quot;fsLayout container-fluid&quot;]/div[@class=&quot;row panel-group&quot;]/fs-group[@class=&quot;fs-scope fs-isolate-scope fsGroup&quot;]/div[@class=&quot;panel panel-default fs-scope anonymous upload-body no-margin-bottom disable-radius col-md-12 col-xs-12&quot;]/div[@class=&quot;panel-body&quot;]/div[@class=&quot;row fs-scope&quot;]/fs-grid[@class=&quot;fs-scope fs-isolate-scope fsGrid&quot;]/div[@class=&quot;float-none col-md-3 col-sm-12 col-xs-12&quot;]/fs-file-upload[@class=&quot;fs-scope fs-isolate-scope&quot;]/div[@class=&quot;fsFileUpload form-group fs-scope&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;form-group col-md-12&quot;]/label[@class=&quot;well drop-zone&quot;]/div[@class=&quot;icon icon-plus&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>.//*[@options='fsComponentCtrl.fileUploadOptions']//*[@class='icon icon-plus']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.icon.icon-plus</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>50b38351-4fca-4a9b-b488-052e9c754bef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>icon icon-plus</value>
      <webElementGuid>f20a8e1c-f278-459c-8efd-35c27f7951be</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;fs-scope&quot;]/body[@class=&quot;app fs-scope v-scroll&quot;]/div[@class=&quot;app-view fs-scope&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;app-content&quot;]/div[@class=&quot;content-body&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;cpt-form editPage fs-scope&quot;]/fs-layout[@class=&quot;fs-isolate-scope&quot;]/div[@class=&quot;fsLayout container-fluid&quot;]/div[@class=&quot;row panel-group&quot;]/fs-group[@class=&quot;fs-scope fs-isolate-scope fsGroup&quot;]/div[@class=&quot;panel panel-default fs-scope anonymous upload-body no-margin-bottom disable-radius col-md-12 col-xs-12&quot;]/div[@class=&quot;panel-body&quot;]/div[@class=&quot;row fs-scope&quot;]/fs-grid[@class=&quot;fs-scope fs-isolate-scope fsGrid&quot;]/div[@class=&quot;float-none col-md-3 col-sm-12 col-xs-12&quot;]/fs-file-upload[@class=&quot;fs-scope fs-isolate-scope&quot;]/div[@class=&quot;fsFileUpload form-group fs-scope&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;form-group col-md-12&quot;]/label[@class=&quot;well drop-zone&quot;]/div[@class=&quot;icon icon-plus&quot;]</value>
      <webElementGuid>c3bd7569-e06c-4f8e-88e2-a4fd3f7124b0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>.//*[@uib-tooltip='Attachment']</value>
      <webElementGuid>af658bfb-a26c-4336-9053-e253e3bdf2e2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
