<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ReverseFactoringLabel</name>
   <tag></tag>
   <elementGuidId>0c462661-3910-4874-87a1-b06d00cd5d04</elementGuidId>
   <imagePath>Screenshots/Targets/Page_TAWRID - Working Capital Finance/MenuPage_ReverseFactoringLabel.png</imagePath>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*/text()[normalize-space(.)='Reverse Factoring']/parent::*</value>
      </entry>
      <entry>
         <key>IMAGE</key>
         <value>Screenshots/Targets/Page_TAWRID - Working Capital Finance/MenuPage_ReverseFactoringLabel.png</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>a >> internal:has-text=&quot;Reverse Factoring&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>678aa40b-d25e-4a41-8e79-6e189bc9e184</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>media-body fs-binding</value>
      <webElementGuid>d83971bf-f9d0-45fb-ae8b-6289421d4ee3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Reverse Factoring</value>
      <webElementGuid>63364248-dab6-4144-aae3-ecc89e116c54</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;fs-scope&quot;]/body[@class=&quot;app fs-scope v-scroll&quot;]/div[@class=&quot;app-view fs-scope&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;app-content&quot;]/div[@class=&quot;content-side fs-scope&quot;]/div[@class=&quot;scroller open ps ps--active-y&quot;]/nav[@class=&quot;navbar navbar-default fs-scope&quot;]/ul[@class=&quot;nav navbar-nav fs-isolate-scope&quot;]/li[@class=&quot;top-menu dropdown fs-scope open allin&quot;]/ul[@class=&quot;fs-menu-items level dropdown-menu&quot;]/li[@class=&quot;dropdown-submenu open fs-scope subMenuTitle&quot;]/ul[@class=&quot;fs-menu-items level1 dropdown-menu&quot;]/li[@class=&quot;dropdown-submenu open fs-scope subMenuTitle&quot;]/a[@class=&quot;media subMenuTitle&quot;]/span[@class=&quot;media-body fs-binding&quot;]</value>
      <webElementGuid>84d2531f-3b42-4ba0-a790-a3c9cdc1c504</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Product Setup'])[1]/following::span[2]</value>
      <webElementGuid>af6364c9-ef62-4f24-9e33-b59ea8d4b428</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Product on-Boarding'])[1]/following::span[4]</value>
      <webElementGuid>9f01f83e-0d71-407d-92cd-dc7133e84808</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Customer on-Boarding'])[1]/preceding::span[3]</value>
      <webElementGuid>3488fdb9-aa2d-44aa-888d-4d6896ed62ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Transaction'])[1]/preceding::span[6]</value>
      <webElementGuid>3c84db60-fffc-463f-abf5-e1cb2415bf14</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Reverse Factoring']/parent::*</value>
      <webElementGuid>6e95808d-5ad3-419d-865a-486a5fdb9e10</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/ul/li[2]/a/span</value>
      <webElementGuid>c1ba9242-dd0e-4727-80a3-8b29de5d3a6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Reverse Factoring' or . = 'Reverse Factoring')]</value>
      <webElementGuid>85c55f63-1431-4b50-ba0f-45571225877c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
