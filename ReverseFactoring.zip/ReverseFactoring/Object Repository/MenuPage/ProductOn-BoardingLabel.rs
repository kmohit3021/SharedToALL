<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProductOn-BoardingLabel</name>
   <tag></tag>
   <elementGuidId>30af8c9f-af5b-42bf-a64f-6156cabfb52b</elementGuidId>
   <imagePath>Screenshots/Targets/Page_TAWRID - Working Capital Finance/MenuPage_ProductOn-BoardingLabel.png</imagePath>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*/text()[normalize-space(.)='Product on-Boarding']/parent::*</value>
      </entry>
      <entry>
         <key>IMAGE</key>
         <value>Screenshots/Targets/Page_TAWRID - Working Capital Finance/MenuPage_ProductOn-BoardingLabel.png</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>a >> internal:has-text=&quot;Product on-Boarding&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>dbea012a-8359-4eb7-9cde-f4179612ca85</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>media-body fs-binding</value>
      <webElementGuid>98c2ad67-b603-4caf-9092-55a5df1946e0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Product on-Boarding</value>
      <webElementGuid>d0f4e39a-1e91-4c3c-858a-d26d7c8bf9ff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;fs-scope&quot;]/body[@class=&quot;app fs-scope v-scroll&quot;]/div[@class=&quot;app-view fs-scope&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;app-content&quot;]/div[@class=&quot;content-side fs-scope&quot;]/div[@class=&quot;scroller open ps ps--active-y&quot;]/nav[@class=&quot;navbar navbar-default fs-scope&quot;]/ul[@class=&quot;nav navbar-nav fs-isolate-scope&quot;]/li[@class=&quot;top-menu dropdown fs-scope open allin&quot;]/ul[@class=&quot;fs-menu-items level dropdown-menu&quot;]/li[@class=&quot;dropdown-submenu open fs-scope subMenuTitle&quot;]/a[@class=&quot;media subMenuTitle&quot;]/span[@class=&quot;media-body fs-binding&quot;]</value>
      <webElementGuid>32b91e07-7a66-44b2-b74b-a56698dbb88b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='System Data Admin'])[1]/following::span[3]</value>
      <webElementGuid>94c08b97-765e-45fb-a16f-4a55b7492ef2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Transaction'])[1]/following::span[5]</value>
      <webElementGuid>f2ef4c27-69d7-4ab2-97c3-7130169443da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Customer on-Boarding'])[1]/preceding::span[3]</value>
      <webElementGuid>e569f2ad-d1a5-4080-9a31-ad4f52ed2226</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Transaction'])[2]/preceding::span[6]</value>
      <webElementGuid>9d307657-9388-45ab-a85f-997f28cdf585</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Product on-Boarding']/parent::*</value>
      <webElementGuid>1b2d209b-61fb-4ec0-93d2-b3822573447c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/a/span[2]</value>
      <webElementGuid>d9e1f6f9-e389-4d96-96a8-3d926b6167a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Product on-Boarding' or . = 'Product on-Boarding')]</value>
      <webElementGuid>05b174f3-5525-494a-8a9f-5d038ea9db2b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
