<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LimitSetupLabel</name>
   <tag></tag>
   <elementGuidId>d7dea4f5-f281-4e1a-96e2-8ef4b083c4e0</elementGuidId>
   <imagePath>Screenshots/Targets/Page_TAWRID - Working Capital Finance/MenuPage_LimitSetupLabel.png</imagePath>
   <selectorCollection>
      <entry>
         <key>IMAGE</key>
         <value>Screenshots/Targets/Page_TAWRID - Working Capital Finance/MenuPage_LimitSetupLabel.png</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Fee Setup'])[1]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>a >> internal:has-text=&quot;Limit Setup&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>964c7da8-3817-4326-b5f7-eeeeaacf7c8c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>media-body fs-binding</value>
      <webElementGuid>b78c7e56-347f-4676-92f8-7302be4cd622</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Limit Setup</value>
      <webElementGuid>dfc6c720-96a7-4974-9dab-575cfa0d737a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;fs-scope&quot;]/body[@class=&quot;app fs-scope v-scroll&quot;]/div[@class=&quot;app-view fs-scope&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;app-content&quot;]/div[@class=&quot;content-side fs-scope&quot;]/div[@class=&quot;scroller open ps ps--active-y&quot;]/nav[@class=&quot;navbar navbar-default fs-scope&quot;]/ul[@class=&quot;nav navbar-nav fs-isolate-scope&quot;]/li[@class=&quot;top-menu dropdown fs-scope open allin&quot;]/ul[@class=&quot;fs-menu-items level dropdown-menu&quot;]/li[@class=&quot;dropdown-submenu open fs-scope subMenuTitle&quot;]/ul[@class=&quot;fs-menu-items level1 dropdown-menu&quot;]/li[@class=&quot;dropdown-submenu open fs-scope subMenuTitle&quot;]/ul[@class=&quot;fs-menu-items level2 dropdown-menu&quot;]/li[@class=&quot;dropdown-submenu open fs-scope subMenuTitle&quot;]/a[@class=&quot;media subMenuTitle&quot;]/span[@class=&quot;media-body fs-binding&quot;]</value>
      <webElementGuid>48e7667d-90e2-4213-8157-b32cfc68a8e0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Fee Setup'])[1]/following::span[1]</value>
      <webElementGuid>fdfc0c55-52ca-4405-bde5-35e51fe84995</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account Setup'])[1]/following::span[2]</value>
      <webElementGuid>e70f0daa-1708-4e9b-947e-6f1a1952df1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reverse Factoring'])[1]/preceding::span[1]</value>
      <webElementGuid>f90a00a8-b7d2-4f65-9796-ed9e7ded0c1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Customer on-Boarding'])[1]/preceding::span[4]</value>
      <webElementGuid>7d4cd605-ca80-4a68-acb7-b85bdaa27fd9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Limit Setup']/parent::*</value>
      <webElementGuid>02d8539e-969a-4e1d-9fbb-4f050c90bce2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/ul/li/ul/li[3]/a/span</value>
      <webElementGuid>ef5105fe-dec8-48be-a271-ef122a8a7a78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Limit Setup' or . = 'Limit Setup')]</value>
      <webElementGuid>a913ee11-16e1-4577-9637-7361ef9cd41e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
