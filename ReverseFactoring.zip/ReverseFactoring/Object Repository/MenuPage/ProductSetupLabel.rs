<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ProductSetupLabel</name>
   <tag></tag>
   <elementGuidId>0d99809b-771d-48a9-b475-c16290fb22b9</elementGuidId>
   <imagePath>Screenshots/Targets/Page_TAWRID - Working Capital Finance/MenuPage_ProductSetupLabel.png</imagePath>
   <selectorCollection>
      <entry>
         <key>IMAGE</key>
         <value>Screenshots/Targets/Page_TAWRID - Working Capital Finance/MenuPage_ProductSetupLabel.png</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.fs-menu-items.level1.dropdown-menu > li.dropdown-submenu.open.fs-scope.subMenuTitle > a.media.subMenuTitle > span.media-body.fs-binding</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Product on-Boarding'])[1]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>a >> internal:has-text=&quot;Product Setup&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>96c6b71d-ce89-428b-8149-c13cd384e0e8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>media-body fs-binding</value>
      <webElementGuid>b583f7c6-0fcb-4eec-8a0c-41dca593ffc4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Product Setup</value>
      <webElementGuid>b3755047-1b33-4291-be1f-df0f5d4aedbe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;fs-scope&quot;]/body[@class=&quot;app fs-scope v-scroll&quot;]/div[@class=&quot;app-view fs-scope&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;app-content&quot;]/div[@class=&quot;content-side fs-scope&quot;]/div[@class=&quot;scroller open ps ps--active-y&quot;]/nav[@class=&quot;navbar navbar-default fs-scope&quot;]/ul[@class=&quot;nav navbar-nav fs-isolate-scope&quot;]/li[@class=&quot;top-menu dropdown fs-scope open allin&quot;]/ul[@class=&quot;fs-menu-items level dropdown-menu&quot;]/li[@class=&quot;dropdown-submenu open fs-scope subMenuTitle&quot;]/ul[@class=&quot;fs-menu-items level1 dropdown-menu&quot;]/li[@class=&quot;dropdown-submenu open fs-scope subMenuTitle&quot;]/a[@class=&quot;media subMenuTitle&quot;]/span[@class=&quot;media-body fs-binding&quot;]</value>
      <webElementGuid>417203ea-9d12-41dd-a187-f221152e0078</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Product on-Boarding'])[1]/following::span[2]</value>
      <webElementGuid>986f1a92-ac59-41d3-b619-a66c4904632b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='System Data Admin'])[1]/following::span[5]</value>
      <webElementGuid>fd57e664-879e-4e06-8441-ba7831cd0620</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reverse Factoring'])[1]/preceding::span[2]</value>
      <webElementGuid>496514ed-7248-421b-9424-74cbb87365db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Customer on-Boarding'])[1]/preceding::span[5]</value>
      <webElementGuid>e36b7b9a-a9e6-4ef0-a3ab-cb96ceaaa09e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Product Setup']/parent::*</value>
      <webElementGuid>fe9a3947-7e5a-467f-8ca0-b7724db23a08</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/ul/li/a/span</value>
      <webElementGuid>83e4d6f7-5092-4a64-b873-01f0c4ee22e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Product Setup' or . = 'Product Setup')]</value>
      <webElementGuid>f40cf1a4-1ad6-4a16-85e1-9546d5dc7088</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
