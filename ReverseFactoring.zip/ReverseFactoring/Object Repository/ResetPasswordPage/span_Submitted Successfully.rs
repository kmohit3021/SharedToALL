<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Submitted Successfully</name>
   <tag></tag>
   <elementGuidId>62a5a1ab-bf55-46ab-86df-965daeff74e4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Utilities'])[1]/following::span[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.successLabel.fs-binding</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>37812f83-4d75-4d75-8c6d-bcc057cb2b8b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>successLabel fs-binding</value>
      <webElementGuid>97c2dbfc-964e-4b27-945e-e379d4c7336a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Submitted Successfully</value>
      <webElementGuid>9cb52790-4c10-434f-b1ba-16363206d150</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;fs-scope&quot;]/body[@class=&quot;app fs-scope v-scroll&quot;]/div[@class=&quot;app-view fs-scope&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;app-content&quot;]/div[@class=&quot;content-body&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;bpt-form acknowledge fs-scope&quot;]/div[@class=&quot;panel-group&quot;]/div[@class=&quot;panel no-margin-bottom padding-top-24 padding-left-24 padding-right-24 padding-bottom-24&quot;]/div[@class=&quot;text-center margin-top-48&quot;]/div[@class=&quot;text-center&quot;]/span[@class=&quot;successLabel fs-binding&quot;]</value>
      <webElementGuid>4b48c248-d39c-40b3-9b31-c1799002bf1d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Utilities'])[1]/following::span[4]</value>
      <webElementGuid>c27cefb6-732e-4a2d-b273-8db531053e8b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Data Analysis'])[1]/following::span[7]</value>
      <webElementGuid>f427c68f-c997-4f8a-b7fa-d0a3bd3b96b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View Transaction Status'])[1]/preceding::span[5]</value>
      <webElementGuid>707ac5ed-af2c-4f1f-b22a-777de35114e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Submitted Successfully']/parent::*</value>
      <webElementGuid>7d175abc-4c8c-40ad-8854-12350b67552c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div/div/div/div/div/div/span</value>
      <webElementGuid>1458b279-edf6-4ed3-8634-9123eaec73d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Submitted Successfully' or . = 'Submitted Successfully')]</value>
      <webElementGuid>de12b2cd-fa9b-4e83-8a87-3db8dfd560e4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
