<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ResetPasswordSubmittedSuccessfullyLabel</name>
   <tag></tag>
   <elementGuidId>087d9be0-87c6-4165-acb1-ea0a3eab8fb0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Submitted Successfully'])[1]/following::span[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.successData.fs-binding</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>09126cd2-852d-4757-bd34-5142b298d8f5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>successData fs-binding</value>
      <webElementGuid>71bd5cf0-e64d-4526-8250-1e77db791ed0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>fs-bind-html</name>
      <type>Main</type>
      <value>vm.acknowledge.title | trustedHtml </value>
      <webElementGuid>ea88728b-edd2-45cc-898c-5514faa91cbe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Company User 10499:ADMINISTRATOR has been submitted for processing.</value>
      <webElementGuid>6269d10c-73a6-49bb-891c-64b92ca440c6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;fs-scope&quot;]/body[@class=&quot;app fs-scope v-scroll&quot;]/div[@class=&quot;app-view fs-scope&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;app-content&quot;]/div[@class=&quot;content-body&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;bpt-form acknowledge fs-scope&quot;]/div[@class=&quot;panel-group&quot;]/div[@class=&quot;panel no-margin-bottom padding-top-24 padding-left-24 padding-right-24 padding-bottom-24&quot;]/div[@class=&quot;text-center margin-top-16 margin-bottom-48&quot;]/span[@class=&quot;fs-scope&quot;]/span[@class=&quot;successData fs-binding&quot;]</value>
      <webElementGuid>b62699e3-dc06-42c7-b48f-358a62b25282</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Submitted Successfully'])[1]/following::span[2]</value>
      <webElementGuid>a952cb74-a9b6-48f5-b19e-3f44f61b42c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Utilities'])[1]/following::span[6]</value>
      <webElementGuid>1d3a4ca8-f4ff-42b1-8efa-a8894e6c1e98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View Transaction Status'])[1]/preceding::span[3]</value>
      <webElementGuid>0c43238b-88bd-4bd7-8b5f-1ce33b83cb17</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View Transaction Status'])[2]/preceding::span[5]</value>
      <webElementGuid>ca8bbe0c-25c7-4b6b-a79e-62a78d7e10ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Company User']/parent::*</value>
      <webElementGuid>5d2ddb08-a24c-427e-8b36-1d0ee15cd23e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/span/span</value>
      <webElementGuid>b8806326-6570-41d0-b62f-07a597629fcc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Company User 10499:ADMINISTRATOR has been submitted for processing.' or . = 'Company User 10499:ADMINISTRATOR has been submitted for processing.')]</value>
      <webElementGuid>15dbe344-12cf-4707-9858-de13ac2a3965</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
