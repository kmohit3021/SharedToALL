<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>PasswordChangedSuccessfullyLabel</name>
   <tag></tag>
   <elementGuidId>e4db202c-09fa-4a67-86a5-6cfeedd2160f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*/text()[normalize-space(.)='Password is changed.']/parent::*</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>55c69f7f-3362-4807-8638-4aa47c443a49</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	                          		Password is changed.
	                            </value>
      <webElementGuid>018e303c-6db3-4cfe-9803-ba152122c616</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;_PageContainer_&quot;)/form[1]/table[1]/tbody[1]/tr[1]/td[@class=&quot;sigon-page-bg&quot;]/table[@class=&quot;signon-panel&quot;]/tbody[1]/tr[1]/td[@class=&quot;logon-bg&quot;]/table[1]/tbody[1]/tr[1]/td[1]/table[@class=&quot;signoff-panel&quot;]/tbody[1]/tr[1]/td[@class=&quot;text-center&quot;]/table[1]/tbody[1]/tr[1]/td[@class=&quot;text-center&quot;]/div[1]/div[@class=&quot;text-center&quot;]/span[1]</value>
      <webElementGuid>3674a41c-a1ad-40e3-ab66-56967a7c6cbb</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='_PageContainer_']/form/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/div/div[3]/span</value>
      <webElementGuid>ed81e28b-f2f4-4ad2-957c-7d0cda2ccd2c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Changed Successfully'])[1]/following::span[1]</value>
      <webElementGuid>e57bf283-3722-4cd6-8044-840c1c0daa3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Password is changed.']/parent::*</value>
      <webElementGuid>e5934307-b905-480e-9f8f-1103fd10ea50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/span</value>
      <webElementGuid>575b8676-c88c-4b52-8db2-d5287b085d42</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
	                          		Password is changed.
	                            ' or . = '
	                          		Password is changed.
	                            ')]</value>
      <webElementGuid>6565665c-5b5f-405e-8029-23e0b9f99464</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
