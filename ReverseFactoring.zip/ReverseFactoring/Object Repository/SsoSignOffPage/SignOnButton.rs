<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SignOnButton</name>
   <tag></tag>
   <elementGuidId>152190c7-bf15-4da6-b3a3-820fc89772cf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[(text() = 'Sign On' or . = 'Sign On')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.btnSignOn > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>da05fe75-f784-44de-b909-590f5ae573f6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign On</value>
      <webElementGuid>9912fd11-b5e4-48aa-ba68-4476fb4c2cf5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;signedoffBox&quot;)/table[1]/tbody[1]/tr[4]/td[1]/button[@class=&quot;appButton&quot;]/span[@class=&quot;btnSignOn&quot;]/span[1]</value>
      <webElementGuid>f0cb504d-1d48-4541-88f4-5a17001dfbcf</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='signedoffBox']/table/tbody/tr[4]/td/button/span/span</value>
      <webElementGuid>f9dd9d81-4908-4b5f-8d73-e1069da20707</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Logged off'])[1]/following::span[2]</value>
      <webElementGuid>04190343-cdf5-4504-be77-9e0cd2685185</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Working Capital Finance'])[2]/following::span[2]</value>
      <webElementGuid>e7f16bba-83ba-4fd3-ab6c-aa66211cd32d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Capture object:'])[1]/preceding::span[1]</value>
      <webElementGuid>c91b458a-2665-4aaf-b54f-f1994671097e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Alt'])[1]/preceding::span[2]</value>
      <webElementGuid>f4da8cff-adb2-488f-97ee-938e367ea2e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sign On']/parent::*</value>
      <webElementGuid>2ad1849f-d209-4601-9dce-063944d4d81a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/span</value>
      <webElementGuid>f4905d32-9c26-4499-ab3c-4f1077102cc4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Sign On' or . = 'Sign On')]</value>
      <webElementGuid>4b48c565-03c0-4295-a9b6-0e259d932097</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
