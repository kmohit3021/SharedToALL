<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>KycSubmittedSuccessfullyLabel</name>
   <tag></tag>
   <elementGuidId>60c49e9c-70ed-4a34-acb0-4aa672e507ee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*/text()[normalize-space(.)='Company Kyc Flag']/parent::*</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.successData.fs-binding</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>e041165c-72da-4a71-817e-e5dda96302d6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>successData fs-binding</value>
      <webElementGuid>b67c7cdd-ab63-454d-ac96-4601f055db0d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>fs-bind-html</name>
      <type>Main</type>
      <value>vm.acknowledge.title | trustedHtml </value>
      <webElementGuid>71d09507-ed73-488a-a97b-52cc539ae3da</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Company Kyc Flag 10016 has been submitted for processing.</value>
      <webElementGuid>7307bcf3-f0d7-4a89-b58c-279155c8f386</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;fs-scope&quot;]/body[@class=&quot;app fs-scope v-scroll&quot;]/div[@class=&quot;app-view fs-scope&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;app-content&quot;]/div[@class=&quot;content-body&quot;]/div[@class=&quot;fs-scope&quot;]/div[@class=&quot;bpt-form acknowledge fs-scope&quot;]/div[@class=&quot;panel-group&quot;]/div[@class=&quot;panel no-margin-bottom padding-top-24 padding-left-24 padding-right-24 padding-bottom-24&quot;]/div[@class=&quot;text-center margin-top-16 margin-bottom-48&quot;]/span[@class=&quot;fs-scope&quot;]/span[@class=&quot;successData fs-binding&quot;]</value>
      <webElementGuid>da3e4622-c60b-4b6e-bef4-470da5d8ef5b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Submitted Successfully'])[1]/following::span[2]</value>
      <webElementGuid>f5f5f2d7-7f34-4253-b89f-2318e6d19d21</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Utilities'])[1]/following::span[6]</value>
      <webElementGuid>37f3dd86-fc02-4498-98f9-1be072278661</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View Transaction Status'])[1]/preceding::span[3]</value>
      <webElementGuid>851bea3f-08ae-436f-aa02-291c82ec872a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View Transaction Status'])[2]/preceding::span[5]</value>
      <webElementGuid>d1563494-cab6-49fe-bfae-dd155ce74004</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Company Kyc Flag']/parent::*</value>
      <webElementGuid>1ed42731-b84c-4943-866a-7ae9d1eb8909</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/span/span</value>
      <webElementGuid>c2561116-fa30-4768-a791-100885f95248</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Company Kyc Flag 10016 has been submitted for processing.' or . = 'Company Kyc Flag 10016 has been submitted for processing.')]</value>
      <webElementGuid>28bafa70-539d-45db-ae95-dde4ec2c1c49</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
