<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ViewTransactionStatusButton</name>
   <tag></tag>
   <elementGuidId>1bf09610-4527-48f2-a750-3d2f3e04bf83</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//span[text()='View Transaction Status'])[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
