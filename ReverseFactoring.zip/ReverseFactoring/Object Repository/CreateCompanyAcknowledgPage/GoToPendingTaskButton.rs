<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>GoToPendingTaskButton</name>
   <tag></tag>
   <elementGuidId>7e9c25fd-e145-47f3-99be-772533f713c3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button/span[text()='Go To Pending Task']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
