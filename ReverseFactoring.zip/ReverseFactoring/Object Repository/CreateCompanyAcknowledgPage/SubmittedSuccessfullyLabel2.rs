<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SubmittedSuccessfullyLabel2</name>
   <tag></tag>
   <elementGuidId>84b6e6f8-078b-4c60-a2b0-e8ad3fce3f29</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>.//*[@class='successData fs-binding']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
