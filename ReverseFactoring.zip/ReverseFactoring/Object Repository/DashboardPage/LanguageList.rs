<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LanguageList</name>
   <tag></tag>
   <elementGuidId>3187f85d-e6b1-4f82-9ef3-9ec744796703</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>.//*[@class='icon icon-language2 dropdown-toggle']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//div[@uib-tooltip='${language}']</value>
      <webElementGuid>1f371342-2b4c-426f-9b1c-a75976239f74</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
