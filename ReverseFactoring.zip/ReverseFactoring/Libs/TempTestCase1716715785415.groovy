import com.kms.katalon.core.main.TestCaseMain
import com.kms.katalon.core.logging.KeywordLogger
import com.kms.katalon.core.testcase.TestCaseBinding
import com.kms.katalon.core.driver.internal.DriverCleanerCollector
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.webui.contribution.WebUiDriverCleaner
import com.kms.katalon.core.mobile.contribution.MobileDriverCleaner
import com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner
import com.kms.katalon.core.windows.keyword.contribution.WindowsDriverCleaner
import com.kms.katalon.core.testng.keyword.internal.TestNGDriverCleaner


DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.webui.contribution.WebUiDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.mobile.contribution.MobileDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.cucumber.keyword.internal.CucumberDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.windows.keyword.contribution.WindowsDriverCleaner())
DriverCleanerCollector.getInstance().addDriverCleaner(new com.kms.katalon.core.testng.keyword.internal.TestNGDriverCleaner())


RunConfiguration.setExecutionSettingFile('/var/folders/s5/xf1t2t8j72q5w8684sr05v4r0000gn/T/Katalon/Test Cases/Funder Program validation Complete flow/20240526_145945/execution.properties')

TestCaseMain.beforeStart()

        TestCaseMain.runTestCaseRawScript(
'''import com.tawrid.function.CommonFunctions as CommonFunctions
import com.tawrid.pages.ChangePasswordPage as ChangePasswordPage
import com.tawrid.pages.CompanyEntityPage as CompanyEntityPage
import com.tawrid.pages.CompanyPage as CompanyPage
import com.tawrid.pages.CreateCompanyAcknowledgePage as CreateCompanyAcknowledgePage
import com.tawrid.pages.CreateCompanyPage as CreateCompanyPage
import com.tawrid.pages.DashboardPage as DashboardPage
import com.tawrid.pages.IndexPage as IndexPage
import com.tawrid.pages.InvoiceUploadPage as InvoiceUploadPage
import com.tawrid.pages.KYCUpdatePage as KYCUpdatePage
import com.tawrid.pages.MenuPage as MenuPage
import com.tawrid.pages.ProfileSetupPage as ProfileSetupPage
import com.tawrid.pages.ResetPasswordPage as ResetPasswordPage
import com.tawrid.pages.SetupPage as SetupPage
import com.tawrid.pages.SsoSignOffPage as SsoSignOffPage
import internal.GlobalVariable as GlobalVariable

/*
 * This test case ensures that once a funder company is created the profile is autocreated.
 * However if the KYC is not verified the solution restricts customer to create a program.
 *
 * */
not_run: DashboardPage.setLanguageForApplication(GlobalVariable.LANGUAGE)

// Test Case 1(Reg_009) : Create a Funder with No Dual Control by a user with No Dual Control
not_run: SetupPage.launchApplicationURL(GlobalVariable.URL_TAWID_PROTOL)

not_run: IndexPage.setLanguageForApplication(GlobalVariable.LANGUAGE)

not_run: IndexPage.enterComapany(GlobalVariable.COMPANY)

not_run: IndexPage.enterUserName(GlobalVariable.USERNAME)

not_run: IndexPage.enterPassword(GlobalVariable.PASSWORD)

not_run: IndexPage.clickLogin()

not_run: DashboardPage.clickCustomerOnBoarding()

not_run: DashboardPage.clickCompanyLabel()

not_run: CompanyEntityPage.clickCreate()

not_run: CreateCompanyPage.selectCompanyType('FUNDER')

not_run: CreateCompanyPage.enterCompanyName()

not_run: CreateCompanyPage.enterCompanyRegistrationID()

not_run: CreateCompanyPage.selectIndustry()

not_run: CreateCompanyPage.enterDescription()

not_run: CreateCompanyPage.enterCity()

not_run: CreateCompanyPage.switchDualControl('No')

not_run: CreateCompanyPage.clickAccessibilityTab()

not_run: CreateCompanyPage.selectAccessibilityRightAllCheckbox()

not_run: CreateCompanyPage.clickAccessibilityRF()

not_run: CreateCompanyPage.selectAccessibilityRightAllCheckbox()

not_run: CreateCompanyPage.clickSubmit()

not_run: println(GlobalVariable.COMPANYCODE)

not_run: String ExpectedMessage = ('Company ' + GlobalVariable.COMPANYCODE) + ' has been submitted for processing.'

not_run: String ActualMessage = CreateCompanyAcknowledgePage.getSubmittedSuccessfullyMessage()

not_run: if (ActualMessage.equals(ExpectedMessage)) {
    CommonFunctions.captureExpectedResult('The Company Creation Message is Displayed as Expected')
} else {
    CommonFunctions.captureExpectedResult((('The was Expecting: ' + ExpectedMessage) + ' but solution displayed: ') + ActualMessage)
}

not_run: CreateCompanyAcknowledgePage.clickViewTransactionStatusButton()

CompanyPage.searchCompnayCode(GlobalVariable.COMPANYCODE)

CompanyPage.getKYCStatus().equals('No')

CompanyPage.getStatus().equals('Verified')

CommonFunctions.captureExpectedResult('The company is created successfully and the status are displayed as expected')

MenuPage.clickProductOnBoarding()

MenuPage.clickReverseFactoring()

MenuPage.clickProfileSetup()

ProfileSetupPage.searchFunderCode(GlobalVariable.COMPANYCODE)

ProfileSetupPage.verifyFunderCodeShouldNotDisplay()

DashboardPage.clickCustomerOnBoarding()

DashboardPage.clickCompanyLabel()

CompanyPage.searchCompnayCode(GlobalVariable.COMPANYCODE)

CompanyPage.clickUpdateKYCResult()

KYCUpdatePage.clickVerify()

KYCUpdatePage.verifyConfirmationDialogue()

KYCUpdatePage.clickConfirm()

KYCUpdatePage.verifyKycSubmittedSuccessfully()

CreateCompanyAcknowledgePage.clickViewTransactionStatusButton()

MenuPage.clickProductOnBoarding()

MenuPage.clickReverseFactoring()

MenuPage.clickProfileSetup()

ProfileSetupPage.searchFunderCode(GlobalVariable.COMPANYCODE)

ProfileSetupPage.verifyFunderCodeShouldDisplay()

DashboardPage.clickCustomerOnBoarding()

DashboardPage.clickCompanyLabel()

CompanyPage.searchCompnayCode(GlobalVariable.COMPANYCODE)

CompanyPage.clickResetAdminPassword()

ResetPasswordPage.verifyResetPasswordPopup()

ResetPasswordPage.clickChooseOneUser('ADMINISTRATOR')

ResetPasswordPage.enterInitialPassword('Testing@1')

ResetPasswordPage.clickOnSubmit()

DashboardPage.clickOnLogoutButton()

SsoSignOffPage.clickOnSignOnButton()

IndexPage.enterComapany(GlobalVariable.COMPANYCODE)

IndexPage.enterUserName('ADMINISTRATOR')

IndexPage.enterPassword('PLGTm/4mhzDkkUX0cje2WQ==')

IndexPage.clickLogin()

ChangePasswordPage.verifyChangePasswordPopup()

ChangePasswordPage.enterOldPassword('Testing@1')

ChangePasswordPage.enterNewPassword('Testing@2')

ChangePasswordPage.enterConfirmNewPassword('Testing@2')

ChangePasswordPage.clickOnSubmit()

ChangePasswordPage.verifyChangePasswordSubmittedSuccessfully()

ChangePasswordPage.clickOkButton()

IndexPage.enterComapany(GlobalVariable.COMPANYCODE)

IndexPage.enterUserName('ADMINISTRATOR')

IndexPage.enterPassword('PLGTm/4mhzCEtyJzMSSXHg==')

IndexPage.clickLogin()

MenuPage.clickReverseFactoring()

MenuPage.clickInvoiceSubmission()

InvoiceUploadPage.clickInvoiceUploadButton()

//InvoiceUploadPage.downlaodTemplateFile()
InvoiceUploadPage.uplaodTemplateFile()

InvoiceUploadPage.verifyFileTemplateUploadedSuccessfuly()

InvoiceUploadPage.clickOnFinalUplaodButton()

''', 'Test Cases/Funder Program validation Complete flow', new TestCaseBinding('Test Cases/Funder Program validation Complete flow',[:]), FailureHandling.STOP_ON_FAILURE , false)
    
