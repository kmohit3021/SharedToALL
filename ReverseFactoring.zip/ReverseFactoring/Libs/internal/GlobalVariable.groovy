package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object URL_TAWID_PROTOL
     
    /**
     * <p></p>
     */
    public static Object COMPANY
     
    /**
     * <p></p>
     */
    public static Object USERNAME
     
    /**
     * <p></p>
     */
    public static Object PASSWORD
     
    /**
     * <p></p>
     */
    public static Object LONG_WAIT
     
    /**
     * <p></p>
     */
    public static Object SHORT_WAIT
     
    /**
     * <p></p>
     */
    public static Object MID_WAIT
     
    /**
     * <p></p>
     */
    public static Object VERYSHORT_WAIT
     
    /**
     * <p></p>
     */
    public static Object LANGUAGE
     
    /**
     * <p></p>
     */
    public static Object COMPANYCODE
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += TestCaseMain.getParsedValues(RunConfiguration.getOverridingParameters(), selectedVariables)
    
            URL_TAWID_PROTOL = selectedVariables['URL_TAWID_PROTOL']
            COMPANY = selectedVariables['COMPANY']
            USERNAME = selectedVariables['USERNAME']
            PASSWORD = selectedVariables['PASSWORD']
            LONG_WAIT = selectedVariables['LONG_WAIT']
            SHORT_WAIT = selectedVariables['SHORT_WAIT']
            MID_WAIT = selectedVariables['MID_WAIT']
            VERYSHORT_WAIT = selectedVariables['VERYSHORT_WAIT']
            LANGUAGE = selectedVariables['LANGUAGE']
            COMPANYCODE = selectedVariables['COMPANYCODE']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
