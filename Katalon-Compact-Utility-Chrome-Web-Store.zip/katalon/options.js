initPortText();
initToggleButton();
addEventHandler();

function initPortText() {
    getKatalonServerPort( function(port) {
        document.getElementById("port").value = port;
    });
}

function initToggleButton() {
    getToggleButtonState( function(state) {
        document.getElementById("show_xpath").checked = state;
    });
}

function addEventHandler() {
    $('#port').on('input', function() {
        setKatalonServerPort($(this).val())
    });

    var toggleButton = document.getElementById("show_xpath");
    if (toggleButton) {
        toggleButton.addEventListener('click', function() {
            setToggleButtonState(this.checked, null);
        });

        chrome.storage.onChanged.addListener(function(changes, namespace) {
            if (namespace === 'local') {
                var state = changes.katalonToggleButtonStateStorage.newValue;
                toggleButton.checked = state;
            }
        });
    }
}